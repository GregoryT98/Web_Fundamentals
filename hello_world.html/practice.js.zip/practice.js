function over(element) {
    alert("mouseover");    
}
    
function out(element) {
    alert("mouseout");    
}

