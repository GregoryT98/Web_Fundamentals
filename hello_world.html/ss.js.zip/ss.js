function change(){
    document.getElementById("plant-1").src="imgs/assets/succulents-2.jpg";
}

function newImage(){
    document.getElementById("plant-1").src="imgs/assets/succulents-1.jpg";
}
    function hide(element){
        element.hide();
}